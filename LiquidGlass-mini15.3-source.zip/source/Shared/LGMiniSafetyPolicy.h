#pragma once
#include <stdint.h>
#include <stdbool.h>
#define LG_MINI_RAPID_WINDOW_MS UINT64_C(180000)
#define LG_MINI_DISABLE_AFTER_STARTS UINT32_C(2)

/* Zero/rewound clocks and corrupt counters never cause wrapping or an unguarded hook. */
static inline uint32_t LGMiniNextRapidStarts(uint64_t previous, uint64_t now, uint32_t count) {
    if (now == 0 || (previous != 0 && now < previous)) return LG_MINI_DISABLE_AFTER_STARTS;
    if (previous == 0 || now - previous > LG_MINI_RAPID_WINDOW_MS) return 1;
    return count >= LG_MINI_DISABLE_AFTER_STARTS - 1 ? LG_MINI_DISABLE_AFTER_STARTS : count + 1;
}
static inline bool LGMiniHealthyStateMatches(int64_t currentBoot, int64_t launchBoot,
                                            uint64_t currentStart, uint64_t launchStart,
                                            uint32_t disabled) {
    return launchBoot > 0 && currentBoot == launchBoot && !disabled &&
           launchStart != 0 && currentStart == launchStart;
}

