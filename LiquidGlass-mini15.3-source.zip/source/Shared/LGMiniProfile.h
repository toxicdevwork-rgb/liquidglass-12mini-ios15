#pragma once
#import <Foundation/Foundation.h>
#import <sys/sysctl.h>
#import <stdio.h>
#import <string.h>
#import <notify.h>
#include "LGMiniStatusIO.h"

static const char *const kLGMiniRendererReadyNote = "dylv.liquidassmini/RendererReady";

static inline void LGMiniPublishRendererReady(BOOL ready) {
    static int token = -1;
    if (token == -1 && notify_register_check(kLGMiniRendererReadyNote, &token) != NOTIFY_STATUS_OK) return;
    notify_set_state(token, ready ? 1 : 0);
    notify_post(kLGMiniRendererReadyNote);
}

static inline BOOL LGMiniRendererState(BOOL refresh) {
    static int ready = 0;
    static int token = -1;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        uint64_t state = 0;
        if (notify_register_dispatch(kLGMiniRendererReadyNote, &token,
            dispatch_get_main_queue(), ^(int changedToken) {
                uint64_t changedState = 0;
                BOOL ok = notify_get_state(changedToken, &changedState) == NOTIFY_STATUS_OK;
                __atomic_store_n(&ready, ok && changedState == 1, __ATOMIC_RELEASE);
            }) == NOTIFY_STATUS_OK) {
            if (notify_get_state(token, &state) == NOTIFY_STATUS_OK)
                __atomic_store_n(&ready, state == 1, __ATOMIC_RELEASE);
        }
    });
    if (refresh) {
        uint64_t state = 0;
        BOOL ok = token != -1 && notify_get_state(token, &state) == NOTIFY_STATUS_OK;
        __atomic_store_n(&ready, ok && state == 1, __ATOMIC_RELEASE);
    }
    return __atomic_load_n(&ready, __ATOMIC_ACQUIRE);
}

static inline BOOL LGMiniRendererReady(void) { return LGMiniRendererState(NO); }
static inline void LGMiniRefreshRendererReady(void) { (void)LGMiniRendererState(YES); }

// Personal build: fail closed on any untested device / OS combination.
static inline BOOL LGMiniDeviceSupported(void) {
    static BOOL supported;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        char machine[64] = {};
        size_t size = sizeof(machine);
        NSOperatingSystemVersion v = NSProcessInfo.processInfo.operatingSystemVersion;
        supported = sysctlbyname("hw.machine", machine, &size, NULL, 0) == 0 &&
            strcmp(machine, "iPhone13,1") == 0 &&
            v.majorVersion == 15 && v.minorVersion == 6 && v.patchVersion == 1;
    });
    return supported;
}

static inline NSDictionary *LGMiniPreferences(NSDictionary *saved) {
    // Full shader/refraction retained. Avoid the user's overlapping tweaks by default.
    NSMutableDictionary *prefs = [@{
        @"Global.Enabled": @YES, @"Global.Quality": @0.75,
        @"Debug.Logging.Enabled": @NO, @"Specular.Motion.Enabled": @NO,
        @"AppIcons.Enabled": @NO, @"Dock.Enabled": @YES,
        @"ControlCenter.Enabled": @NO, @"VolumeHUD.Enabled": @NO,
        @"PillHUD.Enabled": @NO, @"Keyboard.Enabled": @NO,
        @"Clock.Enabled": @NO, @"CoverSheet.Enabled": @YES,
        @"Passcode.Enabled": @NO, @"QuickActions.Enabled": @YES, @"Widgets.Enabled": @YES,
        @"AssistiveTouch.Enabled": @NO, @"SettingsControls.Enabled": @NO,
        @"GlobalControls.Switches.Enabled": @NO,
        @"GlobalControls.Sliders.Enabled": @NO,
        @"GlobalControls.Segmented.Enabled": @NO,
        @"Notification.Enabled": @YES, @"TabBar.Enabled": @YES
    } mutableCopy];
    if ([saved isKindOfClass:NSDictionary.class]) [prefs addEntriesFromDictionary:saved];
    return prefs;
}

static inline void LGMiniStatus(NSString *status) {
    // A failed diagnostic write must not enter Foundation's sandbox-fatal
    // extended-attribute path, or prevent the safe-mode return that follows it.
    char text[256];
    int length = snprintf(text, sizeof(text),
        "LiquidAss mini15.3\niPhone13,1 / iOS 15.6.1\n%s\n", status.UTF8String ?: "unknown");
    if (length <= 0 || (size_t)length >= sizeof(text)) return;
    (void)LGMiniWriteStatusBytes(
        "/var/mobile/Library/Accessibility/liquidass-mini-status.txt", text, (size_t)length);
}
