#pragma once
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stddef.h>
#include <unistd.h>

// Best-effort diagnostic output. Never use Foundation's atomic file writer here:
// iOS 15 backboardd was killed by SANDBOX in its fgetattrlist path.
static inline bool LGMiniWriteStatusBytes(const char *path, const char *bytes, size_t length) {
    int savedErrno = errno;
    if (!path || !bytes || !length || length > 512) return false;
    int flags = O_WRONLY | O_CREAT | O_TRUNC;
#ifdef O_NONBLOCK
    flags |= O_NONBLOCK;
#endif
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif
#ifdef O_NOFOLLOW
    flags |= O_NOFOLLOW;
#endif
    int fd = open(path, flags, 0644);
    if (fd < 0) { errno = savedErrno; return false; }
    size_t written = 0;
    for (unsigned attempt = 0; attempt < 8 && written < length; ++attempt) {
        ssize_t count = write(fd, bytes + written, length - written);
        if (count > 0) written += (size_t)count;
        else if (count < 0 && errno == EINTR) continue;
        else break;
    }
    bool complete = written == length;
    if (close(fd) != 0) complete = false;
    errno = savedErrno;
    return complete;
}
